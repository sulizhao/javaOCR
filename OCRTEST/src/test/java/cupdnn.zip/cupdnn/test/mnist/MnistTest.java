package cupdnn.test.mnist;

import java.io.IOException;
import java.util.List;

import cupdnn.util.DigitImage;

public class MnistTest {
	static List<DigitImage> trains = null ;
	static List<DigitImage> tests = null;
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String basePath = "C:/Users/admin/Downloads/CupDnn-master/";
		//load mnist
		ReadFile rf1=new ReadFile(basePath+"data/mnist/train-labels.idx1-ubyte",basePath+"data/mnist/train-images.idx3-ubyte");
		ReadFile rf2=new ReadFile(basePath+"data/mnist/t10k-labels.idx1-ubyte",basePath+"data/mnist/t10k-images.idx3-ubyte");
		try {
			tests = rf2.loadDigitImages();
			trains =rf1.loadDigitImages();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		MnistNetwork mn = new MnistNetwork();
		mn.buildNetwork(trains.size());
		mn.train(trains,30,tests);

		mn.saveModel("model/mnist.model");
		
		
		mn.loadModel("model/mnist.model");
		mn.test(tests);

	}

}
