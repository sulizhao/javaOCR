package cupdnn.test.cnn;

import cupdnn.Network;
import cupdnn.active.ReluActivationFunc;
import cupdnn.layer.Conv2dLayer;
import cupdnn.layer.FullConnectionLayer;
import cupdnn.layer.InputLayer;
import cupdnn.layer.PoolMaxLayer;
import cupdnn.layer.PoolMeanLayer;
import cupdnn.layer.SoftMaxLayer;
import cupdnn.loss.MSELoss;
import cupdnn.optimizer.SGDOptimizer;

public class CNNTest {
    private  Network network;
    private  SGDOptimizer optimizer;
    public void buildNetwork(int numOfTrainData){
        //首先构建神经网络对象，并设置参数
        network = new Network();
        network.setThreadNum(8);
        network.setBatch(20);
//        network.setLrAttenuation(0.9f);
        network.setLoss(new MSELoss());
        optimizer = new SGDOptimizer(0.1f);
        network.setOptimizer(optimizer);

        buildConvNetwork();

        network.prepare();
    }

    private void buildConvNetwork(){
        InputLayer layer1 =  new InputLayer(network,28,28,1);
        network.addLayer(layer1);

        Conv2dLayer conv1 = new Conv2dLayer(network,28,28,1,8,3,1);
        conv1.setActivationFunc(new ReluActivationFunc());
        network.addLayer(conv1);

        PoolMaxLayer pool1 = new PoolMaxLayer(network,28,28,8,2,2);
        network.addLayer(pool1);

        Conv2dLayer conv2 = new Conv2dLayer(network,14,14,8,8,3,1);
        conv2.setActivationFunc(new ReluActivationFunc());
        network.addLayer(conv2);

        PoolMeanLayer pool2 = new PoolMeanLayer(network,14,14,8,2,2);
        network.addLayer(pool2);

        FullConnectionLayer fc1 = new FullConnectionLayer(network,7*7*8,256);
        fc1.setActivationFunc(new ReluActivationFunc());
        network.addLayer(fc1);

        FullConnectionLayer fc2 = new FullConnectionLayer(network,256,10);
        fc2.setActivationFunc(new ReluActivationFunc());
        network.addLayer(fc2);

        SoftMaxLayer sflayer = new SoftMaxLayer(network,10);
        network.addLayer(sflayer);

    }
}
