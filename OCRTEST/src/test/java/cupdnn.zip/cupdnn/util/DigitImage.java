package cupdnn.util;

public class DigitImage {

	public int label;
	public byte[] imageData;
	
	
	public DigitImage(int label, byte[] imageData)
	{
		this.label=label;
		this.imageData=imageData;
	}  

}
